import csv

INPUT_FILE = "gradebook.csv"
OUTPUT_FILE = "results.csv"

def create_initial_csv():
    """Creates an initial CSV file with headers and sample records."""
    headers = ["student_id", "name", "midterm", "final"]
    
    # Testing records with tricky spaces and punctuation as requested
    students = [
        {"student_id": "101", "name": "Alice M. Smith", "midterm": "85", "final": "90"},
        {"student_id": "102", "name": "O'Connor, Brian", "midterm": "78", "final": "82"},
        {"student_id": "103", "name": "Dr. Jean-Pierre Lee", "midterm": "92", "final": "95"},
        {"student_id": "104", "name": "Diana Prince", "midterm": "55", "final": "58"},
        {"student_id": "105", "name": "Evan Wright, Jr.", "midterm": "70", "final": "74"}
    ]
    
    with open(INPUT_FILE, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=headers)
        writer.writeheader()
        writer.writerows(students)
    print(f"Created '{INPUT_FILE}' with sample records.")

def process_grades(passing_threshold):
    """Reads records using DictReader, calculates averages, displays passing students, and writes results."""
    processed_students = []
    
    print(f"\n--- Students Passing Threshold ({passing_threshold}) ---")
    
    # Read the data
    with open(INPUT_FILE, mode="r", newline="", encoding="utf-8") as file:
        # Use csv.DictReader to automatically handle headers and fields safely
        reader = csv.DictReader(file)
        
        for row in reader:
            # Convert string scores to floats for calculation
            midterm = float(row["midterm"])
            final = float(row["final"])
            average = (midterm + final) / 2
            
            # Save data for the output file
            student_data = {
                "student_id": row["student_id"],
                "name": row["name"],
                "midterm": row["midterm"],
                "final": row["final"],
                "average": round(average, 2)
            }
            processed_students.append(student_data)
            
            # Check and display threshold constraint
            if average >= passing_threshold:
                print(f"ID: {student_data['student_id']} | Name: {student_data['name']:<22} | Average: {student_data['average']}")

    # Write data to a new results file
    output_headers = ["student_id", "name", "midterm", "final", "average"]
    with open(OUTPUT_FILE, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=output_headers)
        writer.writeheader()
        writer.writerows(processed_students)
        
    print(f"\nSuccessfully wrote all calculated grades to '{OUTPUT_FILE}'.")

# --- Run the Script ---
if __name__ == "__main__":
    create_initial_csv()
    
    # Run processing with a chosen threshold of 75
    process_grades(passing_threshold=75.0)
