# 1. Define the dictionary mapping student IDs to names
student_directory = {
    "S101": "Alice",
    "S102": "Bob",
    "S103": "Charlie",
    "S104": "Diana",
    "S105": "Ethan",
    "S106": "Fiona",
    "S107": "George",
    "S108": "Hannah",
    "S109": "Ian",
    "S110": "Julia",
    "S111": "Kevin"
}

# 2. Set the ID you want to look for
search_id = "S104"

# 3. Safe search using dictionary get() method
student_name = student_directory.get(search_id, "Student not found")
print(f"Searching for ID {search_id}: {student_name}")
