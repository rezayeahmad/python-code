import json
import shutil
from pathlib import Path

DATA_FILE = Path("students_data.json")
BACKUP_FILE = Path("students_data.json.bak")

def load_students():
    """Loads student records from the JSON file, handling missing/corrupted data."""
    if not DATA_FILE.exists():
        return {}
    try:
        with open(DATA_FILE, "r", encoding="utf-8") as file:
            return json.load(file)
    except json.JSONDecodeError:
        print("Warning: Data file corrupted. Creating a backup of the corrupt file and resetting.")
        if DATA_FILE.exists():
            shutil.copy(DATA_FILE, Path("students_data_corrupt.json"))
        return {}

def create_backup():
    """Creates a backup file before performing destructive operations."""
    if DATA_FILE.exists():
        shutil.copy(DATA_FILE, BACKUP_FILE)

def save_students(students_dict, destructive=False):
    """Saves student records to the file with mandatory backup for updates/deletes."""
    if destructive:
        create_backup()
    with open(DATA_FILE, "w", encoding="utf-8") as file:
        json.dump(students_dict, file, indent=4)

def validate_fields(student_id, name, department, semester):
    """Validates required fields and checks data formats."""
    if not student_id.strip() or not name.strip() or not department.strip() or not semester.strip():
        print("Error: All fields (ID, Name, Department, Semester) are required.")
        return False
    return True

def add_student(student_id, name, department, semester):
    """Adds a new student record to the system."""
    if not validate_fields(student_id, name, department, semester):
        return
    
    students = load_students()
    if student_id in students:
        print(f"Error: Student with ID {student_id} already exists.")
        return

    students[student_id] = {
        "name": name,
        "department": department,
        "semester": semester
    }
    save_students(students)
    print(f"Successfully added student: {name}")

def list_students():
    """Lists all student records stored in the system."""
    students = load_students()
    if not students:
        print("\nNo student records found.")
        return

    print("\n--- Student List ---")
    for s_id, info in students.items():
        print(f"ID: {s_id} | Name: {info['name']:<15} | Dept: {info['department']:<15} | Sem: {info['semester']}")

def search_student(student_id):
    """Searches for a student by their unique ID."""
    students = load_students()
    if student_id in students:
        info = students[student_id]
        print(f"\nStudent Found -> ID: {student_id} | Name: {info['name']} | Dept: {info['department']} | Sem: {info['semester']}")
    else:
        print(f"\nStudent with ID {student_id} not found.")

def update_student(student_id, name=None, department=None, semester=None):
    """Updates existing student details after making a system backup."""
    students = load_students()
    if student_id not in students:
        print(f"Error: Cannot update. Student ID {student_id} does not exist.")
        return

    # Update only fields that are provided
    if name and name.strip():
        students[student_id]["name"] = name
    if department and department.strip():
        students[student_id]["department"] = department
    if semester and semester.strip():
        students[student_id]["semester"] = semester

    # Mark as a destructive/replacement operation to trigger a backup
    save_students(students, destructive=True)
    print(f"Successfully updated student ID: {student_id} (Backup created).")

def delete_student(student_id):
    """Removes a student record from the system after making a backup."""
    students = load_students()
    if student_id not in students:
        print(f"Error: Cannot delete. Student ID {student_id} does not exist.")
        return

    removed_name = students[student_id]["name"]
    del students[student_id]
    
    # Mark as a destructive/replacement operation to trigger a backup
    save_students(students, destructive=True)
    print(f"Successfully deleted student: {removed_name} (Backup created).")

# --- Interactive Test Workflow ---
if __name__ == "__main__":
    # Reset file for demonstration
    if DATA_FILE.exists():
        DATA_FILE.unlink()

    print("--- 1. Testing Add Operation ---")
    add_student("202601", "Ali Ahmadi", "Computer Science", "3rd")
    add_student("202602", "Ahmad Karimi", "Engineering", "5th")
    add_student("202603", "Zahra Reyhani", "Medicine", "1st")

    print("\n--- 2. Testing List Operation ---")
    list_students()

    print("\n--- 3. Testing Search Operation ---")
    search_student("202602")

    print("\n--- 4. Testing Destructive Update Operation ---")
    update_student("202601", name="Ali Mansoor Ahmadi", semester="4th")

    print("\n--- 5. Testing Destructive Delete Operation ---")
    delete_student("202603")

    print("\n--- 6. Final Student Records Verification ---")
    list_students()
