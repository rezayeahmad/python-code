

import csv
import sys
from datetime import datetime
from pathlib import Path


# 1. PATHS  (all paths handled with pathlib.Path)

BASE_DIR    = Path(__file__).resolve().parent          # project folder
DATA_DIR    = BASE_DIR / "data"
BACKUP_DIR  = BASE_DIR / "backups"
DATA_FILE   = DATA_DIR / "students.csv"
STUDENT_ID_PREFIX = "STU-"                              # required ID format
VALID_DEPARTMENTS = {"Computer Science", "Engineering",
                     "Mathematics", "Physics", "Economics"}
FIELDS = ["student_id", "name", "department", "semester"]



# 2. PATH / FILE HELPERS

def ensure_dirs() -> None:
    """Create data/ and backups/ folders if they do not exist."""
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    BACKUP_DIR.mkdir(parents=True, exist_ok=True)


def create_backup() -> Path | None:
    """Copy the current data file into backups/ with a timestamp.

    Returns the backup path, or None if no file existed yet.
    """
    if not DATA_FILE.exists():
        return None
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_path = BACKUP_DIR / f"students_backup_{stamp}.csv"
    backup_path.write_bytes(DATA_FILE.read_bytes())   # exact byte copy
    return backup_path



# 3. VALIDATION

def validate_student_id(student_id: str) -> bool:
    """ID must look like STU-0001 (prefix + 4 digits)."""
    sid = student_id.strip().upper()
    if not sid.startswith(STUDENT_ID_PREFIX):
        return False
    digits = sid[len(STUDENT_ID_PREFIX):]
    return len(digits) == 4 and digits.isdigit()


def validate_record(name: str, department: str, semester: str) -> list[str]:
    """Return a list of error messages (empty list == valid)."""
    errors = []
    if not name.strip():
        errors.append("Name is required.")
    if department.strip().title() not in {d.title() for d in VALID_DEPARTMENTS}:
        errors.append(f"Department must be one of: {sorted(VALID_DEPARTMENTS)}")
    try:
        sem = int(semester)
        if not 1 <= sem <= 12:
            errors.append("Semester must be between 1 and 12.")
    except ValueError:
        errors.append("Semester must be a whole number.")
    return errors



# 4. PERSISTENCE  (load / save with corruption handling)

def load_students() -> dict[str, dict[str, str]]:
    """Read the CSV file into {student_id: record}.

    Handles three failure cases gracefully:
      * missing file  -> returns empty dict (first run)
      * empty file    -> returns empty dict
      * corrupted row -> skips it and warns the user
    """
    students: dict[str, dict[str, str]] = {}
    if not DATA_FILE.exists():
        print(f"[info] No data file found at {DATA_FILE}. Starting fresh.")
        return students
    try:
        with DATA_FILE.open("r", encoding="utf-8", newline="") as f:
            reader = csv.DictReader(f)
            for line_no, row in enumerate(reader, start=2):
                try:
                    if not row.get("student_id"):          # blank/garbage row
                        raise ValueError("missing student_id")
                    sid = row["student_id"].strip().upper()
                    if not validate_student_id(sid):
                        raise ValueError(f"bad ID format '{sid}'")
                    students[sid] = {
                        "student_id": sid,
                        "name": row["name"].strip(),
                        "department": row["department"].strip(),
                        "semester": row["semester"].strip(),
                    }
                except (ValueError, AttributeError) as exc:
                    print(f"[warn] Skipping corrupted row {line_no}: {exc}")
    except (OSError, csv.Error) as exc:
        print(f"[error] Could not read data file ({exc}). Starting fresh.")
        return {}
    return students


def save_students(students: dict[str, dict[str, str]]) -> None:
    """Write all records back to CSV (atomic via temp file)."""
    ensure_dirs()
    temp_file = DATA_FILE.with_suffix(".tmp")
    with temp_file.open("w", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDS)
        writer.writeheader()
        for sid in sorted(students):
            writer.writerow(students[sid])
    temp_file.replace(DATA_FILE)   # replace only after successful write

# 5. CRUD OPERATIONS  (each function does ONE thing)

def add_student(students: dict, student_id: str, name: str,
                department: str, semester: str) -> bool:
    sid = student_id.strip().upper()
    if not validate_student_id(sid):
        print("Invalid ID. Format must be STU-0001.")
        return False
    if sid in students:
        print(f"Student {sid} already exists. Use update instead.")
        return False
    errors = validate_record(name, department, semester)
    if errors:
        for e in errors:
            print(" -", e)
        return False
    students[sid] = {"student_id": sid, "name": name.strip(),
                     "department": department.strip().title(),
                     "semester": str(int(semester))}
    save_students(students)
    print(f"Added: {students[sid]}")
    return True


def list_students(students: dict) -> None:
    if not students:
        print("No students in the system yet.")
        return
    print(f"{'ID':<10}{'Name':<22}{'Department':<18}{'Semester':<9}")
    print("-" * 60)
    for sid in sorted(students):
        r = students[sid]
        print(f"{r['student_id']:<10}{r['name']:<22}{r['department']:<18}"
              f"{r['semester']:<9}")


def search_student(students: dict, keyword: str) -> list[dict]:
    kw = keyword.strip().lower()
    hits = [r for r in students.values()
            if kw in r["student_id"].lower() or kw in r["name"].lower()]
    if hits:
        for r in hits:
            print(f"Found -> {r}")
    else:
        print(f"No student matches '{keyword}'.")
    return hits


def update_student(students: dict, student_id: str,
                   field: str, new_value: str) -> bool:
    sid = student_id.strip().upper()
    if sid not in students:
        print(f"Student {sid} not found.")
        return False
    if field not in ("name", "department", "semester"):
        print("Field must be one of: name, department, semester.")
        return False
    test = dict(students[sid])
    test[field] = new_value
    errors = validate_record(test["name"], test["department"], test["semester"])
    if errors:
        for e in errors:
            print(" -", e)
        return False
    backup = create_backup()          # backup BEFORE destructive write
    students[sid][field] = new_value.strip().title() if field != "semester" \
        else str(int(new_value.strip()))
    save_students(students)
    print(f"Updated {sid}.{field}. Backup: {backup}")
    return True


def delete_student(students: dict, student_id: str) -> bool:
    sid = student_id.strip().upper()
    if sid not in students:
        print(f"Student {sid} not found.")
        return False
    backup = create_backup()          # backup BEFORE destructive write
    removed = students.pop(sid)
    save_students(students)
    print(f"Deleted {removed}. Backup: {backup}")
    return True



def show_paths() -> None:
    print(f"Data file   : {DATA_FILE}")
    print(f"Backup dir  : {BACKUP_DIR}")
    backups = sorted(BACKUP_DIR.glob("*.csv")) if BACKUP_DIR.exists() else []
    print(f"Backups     : {len(backups)} file(s)")
    for b in backups[-5:]:
        print("   -", b.name)


def run_interactive() -> None:
    ensure_dirs()
    students = load_students()
    while True:
        print(MENU)
        choice = input("Choice: ").strip()
        if choice == "1":
            add_student(students,
                        input("ID (STU-0001): "), input("Name: "),
                        input("Department: "), input("Semester: "))
        elif choice == "2":
            list_students(students)
        elif choice == "3":
            search_student(students, input("Search keyword: "))
        elif choice == "4":
            update_student(students, input("ID: "),
                           input("Field (name/department/semester): "),
                           input("New value: "))
        elif choice == "5":
            delete_student(students, input("ID to delete: "))
        elif choice == "6":
            show_paths()
        elif choice == "0":
            print("Goodbye!")
            break
        else:
            print("Unknown option. Try again.")


if __name__ == "__main__":
    run_interactive()