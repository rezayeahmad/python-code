# List of 11 student scores (including duplicates)
scores = [85, 92, 45, 60, 78, 92, 55, 60, 88, 95, 72]
print("Original Scores List:", scores)
