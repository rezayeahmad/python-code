from typing import TypeVar, List, Dict, Set, Callable, Iterable

# --- Generic Helper Function ---
T = TypeVar('T')

def filter_items(items: Iterable[T], condition: Callable[[T], bool]) -> List[T]:
    """
    A generic helper function using TypeVar to filter any collection 
    based on a provided condition.
    """
    return [item for item in items if condition(item)]


# --- Student Registration Manager ---
class CourseRegistrationManager:
    def __init__(self) -> None:
        # Dictionary indexed by student ID. 
        # Value structure: {"name": str, "courses": Set[str]}
        self.students: Dict[str, Dict[str, any]] = {}

    def add_student(self, student_id: str, name: str) -> None:
        """Adds a new student to the system if the ID is unique."""
        if student_id in self.students:
            print(f"Error: Student ID {student_id} already exists.")
            return
        self.students[student_id] = {
            "name": name,
            "courses": set()  # Set used for tracking unique courses
        }
        print(f"Added student: {name} (ID: {student_id})")

    def register_course(self, student_id: str, course_code: str) -> None:
        """Registers a student for a specific course."""
        if student_id not in self.students:
            print(f"Error: Student ID {student_id} not found.")
            return
        self.students[student_id]["courses"].add(course_code)
        print(f"Registered {self.students[student_id]['name']} into {course_code}")

    def drop_course(self, student_id: str, course_code: str) -> None:
        """Removes a course from a student's registered set."""
        if student_id not in self.students:
            print(f"Error: Student ID {student_id} not found.")
            return
        
        courses: Set[str] = self.students[student_id]["courses"]
        if course_code in courses:
            courses.remove(course_code)
            print(f"Dropped {course_code} for {self.students[student_id]['name']}")
        else:
            print(f"Error: Course {course_code} not found in student's registration.")

    def search_student(self, student_id: str) -> None:
        """Searches and prints a student's details by ID."""
        student = self.students.get(student_id)
        if student:
            print(f"\n--- Student Found ---")
            print(f"ID: {student_id}")
            print(f"Name: {student['name']}")
            print(f"Courses: {', '.join(student['courses']) if student['courses'] else 'None'}")
        else:
            print(f"Student ID {student_id} not found.")

    def display_all_unique_courses(self) -> None:
        """Displays a completely unique list of all courses registered across the system."""
        # Using a set comprehension to gather all unique courses
        unique_courses: Set[str] = {course for student in self.students.values() for course in student["courses"]}
        print(f"\nAll Unique Registered Courses: {', '.join(sorted(unique_courses)) if unique_courses else 'None'}")

    def find_students_sharing_course(self, course_code: str) -> None:
        """Finds and lists all students enrolled in a specific course."""
        # Leveraging the generic helper function with a lambda condition
        sharing_students = filter_items(
            self.students.items(), 
            lambda item: course_code in item[1]["courses"]
        )
        
        print(f"\nStudents enrolled in {course_code}:")
        if not sharing_students:
            print("No students registered for this course.")
            return
            
        for student_id, data in sharing_students:
            print(f"- {data['name']} (ID: {student_id})")

    def display_sorted_students(self) -> None:
        """Sorts all students alphabetically by name and displays them."""
        # Sorting the dictionary items by the 'name' field
        sorted_students = sorted(self.students.items(), key=lambda item: item[1]["name"])
        
        print("\n--- Student Roster (Sorted by Name) ---")
        for student_id, data in sorted_students:
            courses_str = ", ".join(data["courses"]) if data["courses"] else "None"
            print(f"Name: {data['name']} | ID: {student_id} | Courses: [{courses_str}]")


# --- Demonstration Execution ---
if __name__ == "__main__":
    manager = CourseRegistrationManager()

    print("--- 1. Adding Students ---")
    manager.add_student("S101", "Charlie Brown")
    manager.add_student("S102", "Alice Smith")
    manager.add_student("S103", "Bob Jones")

    print("\n--- 2. Registering Courses ---")
    manager.register_course("S101", "CS101")
    manager.register_course("S101", "MATH201")
    manager.register_course("S102", "CS101")
    manager.register_course("S102", "BIO104")
    manager.register_course("S103", "MATH201")

    print("\n--- 3. Drop Course Example ---")
    manager.drop_course("S102", "BIO104")

    print("\n--- 4. Search Student Example ---")
    manager.search_student("S101")

    print("\n--- 5. Unique Courses & Course Sharing Lookups ---")
    manager.display_all_unique_courses()
    manager.find_students_sharing_course("CS101")

    print("\n--- 6. Sorted Roster Display ---")
    manager.display_sorted_students()
