# 1. First, define the list of scores
scores = [85, 92, 45, 60, 78, 92, 59, 88, 72, 60, 95]

# 2. Perform the calculations
min_score = min(scores)
max_score = max(scores)
avg_score = sum(scores) / len(scores)

# 3. Print the results
print(f"Minimum Score: {min_score}")
print(f"Maximum Score: {max_score}")
print(f"Average Score: {avg_score:.2f}")
