from abc import ABC, abstractmethod

# ==========================================
# 1. Abstract Base Class with Encapsulation
# ==========================================
class Account(ABC):
    def __init__(self, account_number: str, holder_name: str, initial_balance: float = 0.0):
        self.account_number = account_number
        self.holder_name = holder_name
        # Encapsulation: balance is private to restrict direct modification
        self._balance = initial_balance 

    @property
    def balance(self) -> float:
        return self._balance

    def deposit(self, amount: float):
        if amount <= 0:
            raise ValueError("Deposit amount must be positive.")
        self._balance += amount
        print(f"Deposited ${amount:.2f} into Account {self.account_number}. New Balance: ${self._balance:.2f}")

    def withdraw(self, amount: float):
        if amount <= 0:
            raise ValueError("Withdrawal amount must be positive.")
        if amount > self._balance:
            raise ValueError("Insufficient funds.")
        self._balance -= amount
        print(f"Withdrew ${amount:.2f} from Account {self.account_number}. New Balance: ${self._balance:.2f}")

    @abstractmethod
    def process_end_of_month(self):
        """Abstract method to override for calculating fees or benefits."""
        pass

    def __str__(self):
        return f"{self.__class__.__name__} ({self.account_number}) - Holder: {self.holder_name} | Balance: ${self._balance:.2f}"


# ==========================================
# 2. Subclasses Overriding Benefits/Fees
# ==========================================
class SavingsAccount(Account):
    def __init__(self, account_number: str, holder_name: str, initial_balance: float, interest_rate: float = 0.02):
        super().__init__(account_number, holder_name, initial_balance)
        self.interest_rate = interest_rate  # Benefit rule

    def process_end_of_month(self):
        # Calculate interest benefit
        interest = self._balance * self.interest_rate
        self._balance += interest
        print(f"[Benefit] Interest of ${interest:.2f} added to Savings {self.account_number}.")


class CurrentAccount(Account):
    def __init__(self, account_number: str, holder_name: str, initial_balance: float, monthly_fee: float = 12.00):
        super().__init__(account_number, holder_name, initial_balance)
        self.monthly_fee = monthly_fee  # Fee rule

    def process_end_of_month(self):
        # Calculate and deduct maintenance fee
        if self._balance >= self.monthly_fee:
            self._balance -= self.monthly_fee
            print(f"[Fee] Monthly maintenance fee of ${self.monthly_fee:.2f} deducted from Current {self.account_number}.")
        else:
            print(f"[Warning] Insufficient balance in Current {self.account_number} to deduct fee.")


# ==========================================
# 3. Polymorphism in Action
# ==========================================
if __name__ == "__main__":
    # Create a list containing different types of accounts
    accounts_list = [
        SavingsAccount("SAV-101", "Alice Smith", 5000.00, interest_rate=0.03),
        CurrentAccount("CUR-202", "Bob Jones", 1500.00, monthly_fee=15.00)
    ]

    print("--- Initial Account States ---")
    for acc in accounts_list:
        print(acc)

    print("\n--- Performing Encapsulated Transactions ---")
    accounts_list[0].deposit(500.00)     # Alice deposits
    accounts_list[1].withdraw(200.00)    # Bob withdraws

    print("\n--- Polymorphic Monthly Processing (Fees & Benefits) ---")
    for acc in accounts_list:
        # Every object handles this call differently based on its type
        acc.process_end_of_month()

    print("\n--- Final Account States ---")
    for acc in accounts_list:
        print(acc)
