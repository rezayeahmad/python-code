# 1. Define the missing datasets first
scores = [85, 92, 78, 60, 45, 92, 88, 74, 60, 81, 95]

student_directory = {
    "S101": "Alice",
    "S102": "Bob",
    "S103": "Charlie",
    "S104": "Diana",
    "S105": "Ethan",
    "S106": "Fiona",
    "S107": "George",
    "S108": "Hannah",
    "S109": "Ian",
    "S110": "Julia",
    "S111": "Kevin"
}

# 2. Extract lists of IDs and Names in matching order
student_ids = list(student_directory.keys())
student_names = list(student_directory.values())

# 3. Use zip() to combine IDs, Names, and Scores
student_records = list(zip(student_ids, student_names, scores))

# 4. Sort the student records by score in descending order
sorted_records = sorted(student_records, key=lambda record: record[2], reverse=True)

print("\n--- Sorted Student Leaderboard ---")
# 5. Use enumerate() to display rank numbers starting from 1
for rank, (st_id, name, score) in enumerate(sorted_records, start=1):
    print(f"Rank {rank}: [ID: {st_id}] {name} - Score: {score}")
