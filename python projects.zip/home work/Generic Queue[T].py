from typing import TypeVar, Generic, List

# Define the Generic placeholder type variable
T = TypeVar('T')

class Queue(Generic[T]):
    def __init__(self) -> None:
        self._items: List[T] = []

    def enqueue(self, item: T) -> None:
        """Add an item to the back of the queue."""
        self._items.append(item)

    def dequeue(self) -> T:
        """Remove and return the front item of the queue."""
        if self.is_empty():
            raise IndexError("dequeue from empty queue")
        return self._items.pop(0)  # Removes from the front

    def is_empty(self) -> bool:
        return len(self._items) == 0

    def size(self) -> int:
        return len(self._items)

# # Quick Queue Test
print("\n--- Queue[str] Test ---")
queue: Queue[str] = Queue()
queue.enqueue("First")
queue.enqueue("Second")
print(f"Dequeued: {queue.dequeue()}")  # Expected: First
