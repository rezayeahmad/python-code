# Dictionary mapping IDs to names
student_directory = {
    "S101": "Alice",
    "S102": "Bob",
    "S103": "Charlie",
    "S104": "Diana",
    "S105": "Ethan",
    "S106": "Fiona",
    "S107": "George",
    "S108": "Hannah",
    "S109": "Ian",
    "S110": "Julia",
    "S111": "Kevin"
}
print("Student Directory:", student_directory)
