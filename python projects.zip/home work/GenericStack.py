from typing import TypeVar, Generic, List, Optional

# Define a TypeVar to act as the generic placeholder type
T = TypeVar('T')

class Stack(Generic[T]):
    def __init__(self) -> None:
        # Use an underlying list to hold the stack items
        self._items: List[T] = []

    def push(self, item: T) -> None:
        self._items.append(item)

    def pop(self) -> T:
        if self.is_empty():
            raise IndexError("pop from empty stack")
        return self._items.pop()

    # --- Task 1: Add peek() ---
    def peek(self) -> Optional[T]:
        """Return the top element without removing it. Returns None if empty."""
        if self.is_empty():
            return None
        return self._items[-1]

    # --- Task 2: Add is_empty() ---
    def is_empty(self) -> bool:
        """Return True if stack is empty, otherwise False."""
        return len(self._items) == 0

    # --- Task 3: Add size() ---
    def size(self) -> int:
        """Return the total number of items in the stack."""
        return len(self._items)


# ==========================================
# Testing & Examples
# ==========================================

# --- Task 4: Create Stack[int] and Stack[str] examples ---
print("--- Stack[int] Example ---")
int_stack: Stack[int] = Stack()
int_stack.push(10)
int_stack.push(20)
print(f"Stack size: {int_stack.size()}")       # Expected: 2
print(f"Top element (peek): {int_stack.peek()}") # Expected: 20
print(f"Popped element: {int_stack.pop()}")     # Expected: 20
print(f"Top element now: {int_stack.peek()}")   # Expected: 10

print("\n--- Stack[str] Example ---")
str_stack: Stack[str] = Stack()
str_stack.push("Apple")
str_stack.push("Banana")
print(f"Top element: {str_stack.peek()}")      # Expected: Banana


# --- Task 5: Test popping from an empty stack ---
print("\n--- Testing Empty Stack Exception ---")
empty_stack: Stack[int] = Stack()
try:
    empty_stack.pop()
except IndexError as e:
    print(f"Caught expected error: {e}")        # Expected: pop from empty stack
