# 1. Define the scores list first (including duplicate values)
scores = [85, 92, 78, 60, 45, 92, 88, 73, 60, 95, 81]

# 2. Convert to a set and print
scores_set = set(scores)
print("Scores converted to a Set:", scores_set)
