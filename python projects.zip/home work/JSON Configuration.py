import json
import os

FILENAME = "config.json"

# Reasonable default configuration if the file doesn't exist
DEFAULT_CONFIG = {
    "application_name": "Kabul University Portal",
    "version": "1.0.4",
    "settings": {
        "admin_user": "Ali_Ahmadi",
        "theme": "Dark",
        "max_connections": 50,
        "backup_enabled": True
    }
}

def load_configuration():
    """Loads configuration when program starts or falls back to a default."""
    if not os.path.exists(FILENAME):
        print(f"'{FILENAME}' not found. Initializing with default Afghan system values...")
        save_configuration(DEFAULT_CONFIG)
        return DEFAULT_CONFIG
    
    try:
        with open(FILENAME, "r", encoding="utf-8") as file:
            config_data = json.load(file)
            print("Configuration loaded successfully upon startup.")
            return config_data
    except json.JSONDecodeError:
        print(f"Error parsing '{FILENAME}'. File is corrupted. Loading defaults.")
        return DEFAULT_CONFIG

def save_configuration(config_data):
    """Writes the configuration data back to the file with clean indentation."""
    with open(FILENAME, "w", encoding="utf-8") as file:
        # indent=4 creates human-readable spacing
        json.dump(config_data, file, indent=4)
    print(f"Configuration successfully saved to '{FILENAME}'.")

# --- Program Execution Execution Flow ---
if __name__ == "__main__":
    # 1 & 2. Load configuration on startup (creates defaults if missing)
    config = load_configuration()
    
    # 3. Read nested settings
    print("\n--- Reading Nested Settings ---")
    current_admin = config["settings"]["admin_user"]
    current_theme = config["settings"]["theme"]
    print(f"Application: {config['application_name']} (v{config['version']})")
    print(f"Current Admin User: {current_admin}")
    print(f"Current System Theme: {current_theme}")
    
    # 4. Modify one setting in memory
    print("\n--- Modifying Settings in Memory ---")
    # Simulating changing the system administrator role to Ahmad
    config["settings"]["admin_user"] = "Ahmad_Karimi"
    config["settings"]["theme"] = "Light" 
    print(f"Updated Admin User in memory to: {config['settings']['admin_user']}")
    
    # 5. Write the updated configuration back with indentation
    print("\n--- Writing Back to File ---")
    save_configuration(config)
