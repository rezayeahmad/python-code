# Define the scores list first so Python can find it
scores = [85, 92, 45, 60, 78, 92, 55, 88, 60, 72, 95]

# Filtering scores that are greater than or equal to 60
passing_scores = [score for score in scores if score >= 60]
print("Scores >= 60:", passing_scores)

