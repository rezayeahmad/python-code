# 1. Create instances
from Person import Lecturer, Student, Course

prof_jones = Lecturer("Dr. Jones", "jones@university.edu", "L992")
alice = Student("Alice Smith", "alice@student.edu", "S001")
bob = Student("Bob Code", "bob@student.edu", "S002")

# 2. Setup the course (Composition)
advanced_prog = Course("Advanced Programming", prof_jones)
advanced_prog.add_student(alice)
advanced_prog.add_student(bob)

# Print course overview using its __str__ method
print("--- Course Structure ---")
print(advanced_prog)
print("\n" + "="*40 + "\n")

# 3. Polymorphism list containing different subclasses of Person
people_list = [prof_jones, alice, bob]

print("--- Polymorphic Iteration ---")
for person in people_list:
    # Automatically triggers the correct __str__ and role_info() per object type
    print(f"String representation: {person}")
    print(f"Method Override:       {person.role_info()}")
    print("-" * 30)
