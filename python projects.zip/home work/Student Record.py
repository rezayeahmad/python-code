import os

FILENAME = "students.txt"

def initialize_file():
    """Creates the file and writes at least five student records."""
    # Format used: ID, Name, Grade
    records = [
        "101,Alice Smith,A\n",
        "102,Bob Jones,B\n",
        "103,Charlie Brown,A\n",
        "104,Diana Prince,C\n",
        "105,Evan Wright,B\n"
    ]
    # Using a context manager ('with') to write
    with open(FILENAME, "w") as file:
        file.writelines(records)
    print(f"File '{FILENAME}' created with 5 initial records.")

def display_all_records():
    """Reads and displays all records from the file with error handling."""
    try:
        # Using a context manager ('with') to read
        with open(FILENAME, "r") as file:
            print("\n--- Student Records ---")
            for line in file:
                print(line.strip())
    except FileNotFoundError:
        print(f"Error: The file '{FILENAME}' does not exist.")

def search_student_by_id(student_id):
    """Searches for a student record by their unique ID."""
    try:
        with open(FILENAME, "r") as file:
            for line in file:
                # Split line by comma to isolate the ID
                parts = line.strip().split(",")
                if parts[0] == str(student_id):
                    print(f"\nStudent Found: ID: {parts[0]}, Name: {parts[1]}, Grade: {parts[2]}")
                    return
            print(f"\nStudent with ID {student_id} not found.")
    except FileNotFoundError:
        print(f"Error: The file '{FILENAME}' does not exist.")

def append_student(student_id, name, grade):
    """Appends a new student record to the end of the file."""
    new_record = f"{student_id},{name},{grade}\n"
    try:
        # Using context manager with append mode ('a')
        with open(FILENAME, "a") as file:
            file.write(new_record)
        print(f"\nSuccessfully added student: {name}")
    except FileNotFoundError:
        print(f"Error: The file '{FILENAME}' does not exist.")

def count_total_records():
    """Counts and displays the total number of records in the file."""
    try:
        with open(FILENAME, "r") as file:
            count = sum(1 for line in file if line.strip())
        print(f"\nTotal student records: {count}")
    except FileNotFoundError:
        print(f"Error: The file '{FILENAME}' does not exist.")

# --- Execution Workflow ---
if __name__ == "__main__":
    # 1. Create file & write 5 records
    initialize_file()
    
    # 2. Read and display all records
    display_all_records()
    
    # 3. Search for a student by ID
    search_student_by_id(103)
    
    # 4. Append a new student
    append_student(106, "Fiona Gallagher", "A")
    
    # 5. Count total records after append
    count_total_records()
    
    # 6. Demonstrating file-does-not-exist handling
    print("\n--- Testing Error Handling ---")
    # Temporarily renaming to trigger error
    if os.path.exists(FILENAME):
        os.rename(FILENAME, "temp_" + FILENAME)
        
        # This will trigger FileNotFoundError handling
        display_all_records()
        
        # Restore file back to original name
        os.rename("temp_" + FILENAME, FILENAME)
